/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <string.h>
#include <stdio.h>

#include "../../Drivers/bme280/BME280_STM32.h"
#include "../../Drivers/scd30/scd30.h"
#include "../../Drivers/rf95/rf95.h"



/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
		struct frame_t {
			uint8_t id;
			float batt_voltage;
			float bme_temp;
			float bme_rh;
			float bme_pressure;
			float scd30_temp;
			float scd30_rh;
			float scd30_co2;
			float sds_pm25;
			float sds_pm10;
	} __attribute__((__packed__));

	




/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART2_UART_Init();
  MX_USART1_UART_Init();
  MX_I2C1_Init();
  /* USER CODE BEGIN 2 */

	/*char message[128] = "hello";
	HAL_UART_Transmit(&huart2,(const uint8_t *)message,strlen((const char*)message),1000);
	*/
	BME280_Config(&hi2c1,OSRS_2, OSRS_16, OSRS_1, MODE_NORMAL, T_SB_0p5, IIR_16);
	SCD_30_Init(&hi2c1);  

	Init_RF95(&huart1, 434);

	/*codigo dado para o tp5_rf95*/


  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
	
  while (1)
  {
		
	BME280_Measure();
  		
	float Hum = BME280_Measure_Get_Humidity();
	float Tem = BME280_Measure_Get_Temperature();
	float Pre = BME280_Measure_Get_Pressure();
		
	/*char s_hum = (char)Hum;
	char s_tem = (char)Tem;
	char s_pre = (char)Pre;*/
		
	char message2[256];
	snprintf(message2, sizeof(message2), "Temp = %.2f\n\rHum = %.2f \n\rPre = %.2f\n\r", Tem, Hum, Pre);
	HAL_UART_Transmit(&huart2,(uint8_t *)message2,strlen((const char*)message2),1000);
		
	float car_temp;
	float car_co2;
	float car_rh;
		
		
	if (SCD30_dataAvailable() == true){
			float Hum_scd30 = SCD30_Get_Humidity();
			float Temp_scd30 = SCD30_Get_Temperature();
			float CO_scd30 = SCD30_Get_Co2();
			car_temp = Temp_scd30;
			car_co2 = CO_scd30;
			car_rh = Hum_scd30;
		
		struct frame_t measurements;
			measurements.batt_voltage = 3.3;
			measurements.id = 16;
			measurements.bme_pressure = Pre;
			measurements.bme_rh = Hum;
			measurements.bme_temp = Tem;
			measurements.scd30_temp = car_temp;
			measurements.scd30_rh = car_rh;
			measurements.scd30_co2 = car_co2;
			measurements.sds_pm25 = 8.8;
			measurements.sds_pm10 = 4.4;

		//send_RF95((uint8_t*)& measurements, sizeof(measurements));		
		/*char message3[256];
		snprintf(message3, sizeof(message3), "Temp_scd30 = %.2f\n\rHum_scd30 = %.2f \n\rCO_scd30 = %.2f\n\r", Temp_scd30, Hum_scd30, CO_scd30);
		HAL_UART_Transmit(&huart2,(uint8_t *)message3,strlen((const char*)message3),1000);
		*/
		// Dentro do if (SCD30_dataAvailable() == true)
	char csv_buffer[256];

	// Monta a string exatamente no formato de uma linha de CSV
	snprintf(csv_buffer, sizeof(csv_buffer), "%.2f,%d,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f,%.2f\r\n",
         3.3, // batt_voltage (exemplo)
         16,  // id
         Pre, // bme_pressure
         Hum, // bme_rh
         Tem, // bme_temp
         Temp_scd30,
         Hum_scd30,
         CO_scd30,
         8.8, // sds_pm25 (exemplo)
         4.4  // sds_pm10 (exemplo)
	);

	// Envia a string formatada para o PC via cabo USB/Serial
	HAL_UART_Transmit(&huart2, (uint8_t *)csv_buffer, strlen(csv_buffer), 1000);
	
	}
	/*
	char message4[256];
	snprintf(message4, sizeof(message4), "===========New values=========\n\r");
	HAL_UART_Transmit(&huart2,(uint8_t *)message4,strlen((const char*)message4),1000);
*/
	


		HAL_Delay (10000);
	
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_NONE;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_HSI;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_0) != HAL_OK)
  {
    Error_Handler();
  }
  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_USART1|RCC_PERIPHCLK_I2C1;
  PeriphClkInit.Usart1ClockSelection = RCC_USART1CLKSOURCE_PCLK1;
  PeriphClkInit.I2c1ClockSelection = RCC_I2C1CLKSOURCE_HSI;
  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
